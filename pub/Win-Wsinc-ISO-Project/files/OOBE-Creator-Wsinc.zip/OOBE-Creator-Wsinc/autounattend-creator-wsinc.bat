@echo off&cls

:: Esse script escreve (gera) um arquivo de resposta e o salva em uma
:: pasta espec�fica do computador com o nome "autounattend.xml".
::
:: Uma ferramenta de cria��o pr�pria e desenvolvida por WsSolInfor e de
:: acordo com os termos e documenta��o oficial da Microsoft Corporation.
::
:: Mais informa��es sobre uso ou servi�os podem ser encontradas abaixo:
:: https://t.me/wssolinforbot
:: https://wa.me/5584991340398
::
:: script	/ created by Wsinc
:: vers�o	/ v8.0
:: licen�a	/ MIT License
:: contato 	/ @wssolinfor
:: repogit	/ https://github.com/wssolinfor

title OOBE-Creator-Wsinc

for %%c in (C D E F G H I J K L M N O P Q R S T U V W Y Z) do if exist %%c:\Win-Wsinc-ISO set files=%%c:\Win-Wsinc-ISO
set "dir_files=%files%"

::
:: === IN�CIO DE APLICATIVO === ::
::

:: Cria espa�o vazio - Uso Global
for /F %%a in ('echo prompt $H ^| cmd') do set "BS=%%a"
chcp 1252 >nul

::
::  Menu Principal  ::
::
:menu_oobesystem
echo.
echo              :: ================================================== ::
echo              :: Gerador de arquivo de resposta para automatizar as ::
echo              :: configura��es do usu�rio na tela de boas vindas!   ::
echo              :: ================================================== ::
echo.
echo  Esse script escreve um arquivo de resposta e o salva em uma pasta espec�fica do
echo  sistema com o nome "autounattend.xml".
echo.
echo  Ao passo da primeira experi�ncia do usu�rio o arquivo "autounattend.xml" � carregado
echo  e responde as configura��es pedidas e, ignora outras de forma autom�tica levando o
echo  usu�rio diretamente para a �rea de Trabalho do Sistema instalado.
echo.
echo  O arquivo de resposta aplica-se a todas as edi��es do Windows 10 e 11 de 32 e de 64 bits.

powershell -NoProfile -ExecutionPolicy Bypass -Command "Set-ExecutionPolicy Bypass -Scope Process -Force; " ^
	"Write-Host ' Selecione a Arquitetura do SO a ser instalado: ' -ForegroundColor Black; "
	
echo  [1] - 32 Bits (x86)
echo  [2] - 64 Bits (amd64) [RECOMENDADO]
echo  [0] - Sair
echo.
:select_options
choice /C 120 /N /M "%BS% Digite o N�mero da Op��o (Ex.: 1,2,0): "
if %ERRORLEVEL% equ 1 set "ARCH=x86"
if %ERRORLEVEL% equ 2 set "ARCH=amd64"
if %ERRORLEVEL% equ 3 exit
set "ARCH=%ARCH: =%"
goto validate_adminuser

::
:: Valida��o de nome de usu�rio
::
:validate_adminuser
echo.
set "ADMINUSER="
set /p "ADMINUSER=%BS% Defina um nome de usu�rio para o SO instalado: "

if "%ADMINUSER%"=="" (
	echo.
	powershell -Command "Write-Host ' ' -ForegroundColor Red -NoNewline; " ^
	"Write-Host '[ERRO]:' -BackgroundColor DarkRed -ForegroundColor White -NoNewline; " ^
	"Write-Host ' O nome de usu�rio n�o pode estar vazio! ' -ForegroundColor Red"
    goto validate_adminuser
)

::
:: Condi��o de apenas letras, permite apenas um espa�o entre as palavras e n�meros
::
powershell -Command "if ('%ADMINUSER%' -match '^(?!.* {2})[a-zA-Z0-9]+(?: [a-zA-Z0-9]+)*$') { exit 0 } else { exit 1 }"

if errorlevel 1 (
	echo.
	powershell -Command "Write-Host ' ' -ForegroundColor Red -NoNewline; " ^
	"Write-Host '[ERRO]:' -BackgroundColor DarkRed -ForegroundColor White -NoNewline; " ^
	"Write-Host ' Use apenas letras sem acento e n�meros! ' -ForegroundColor Red; " ^
	"Write-Host ' '; " ^
	"Write-Host ' ' -NoNewline; " ^
	"Write-Host ' N�o permitido:' -BackgroundColor Yellow -ForegroundColor Black -NoNewline; " ^
	"Write-Host ' Acentos, in�cio ou final com espa�o, mais de um espa�o ou caracteres especiais. ' -ForegroundColor Yellow; "
	goto validate_adminuser
)
goto validate_password

::
:: Valida��o de senha
::
:validate_password
echo.
set "PASSWORD="
set /p "PASSWORD=%BS% Defina uma senha para o usu�rio definido: "

if "%PASSWORD%"=="" (
	echo.
	powershell -Command "Write-Host ' ' -ForegroundColor Red -NoNewline; " ^
	"Write-Host '[ERRO]:' -BackgroundColor DarkRed -ForegroundColor White -NoNewline; " ^
	"Write-Host ' A senha n�o pode estar vazia! ' -ForegroundColor Red"
    goto validate_password
)
if not "%PASSWORD: =%"=="%PASSWORD%" (
	echo.
	powershell -Command "Write-Host ' ' -ForegroundColor Red -NoNewline; " ^
	"Write-Host '[ERRO]:' -BackgroundColor DarkRed -ForegroundColor White -NoNewline; " ^
	"Write-Host ' A senha n�o pode conter espa�os! ' -ForegroundColor Red"
    goto validate_password
)
echo.
if not exist "%USERPROFILE%\Downloads\Autounattend-Wsinc\" mkdir "%USERPROFILE%\Downloads\Autounattend-Wsinc\"

if exist "%USERPROFILE%\Downloads\Autounattend-Wsinc\autounattend.xml" (
    cls & echo  J� existe um arquivo "autounattend" na pasta:
	echo.
	echo  "%USERPROFILE%\Downloads\Autounattend-Wsinc"
	echo.
	echo  Verifique este arquivo antes ou o exclua para criar outro.
	echo.
	echo.
	echo  Pressione qualquer tecla para voltar ao Menu. . .
	pause >nul
	cls
    goto menu_oobesystem
)

	powershell -Command "Write-Host ' ' -NoNewline; " ^
	"Write-Host '[OK]:' -BackgroundColor DarkGreen -ForegroundColor White -NoNewline; " ^
	"Write-Host ' Valida��es Passadas com Sucesso! ' -ForegroundColor Green; " ^
	"Write-Host ' '; " ^
	"Write-Host ' - Arquitetura selecionada: """%ARCH%"""' -ForegroundColor White; " ^
	"Write-Host ' - Nome de usu�rio: """%ADMINUSER%"""' -ForegroundColor White; " ^
	"Write-Host ' - Senha criada: """%PASSWORD%"""' -ForegroundColor White; "
	timeout /t 3 >nul
	
:ping1
cls
chcp 1252 >nul
echo.
echo  Criando o seu arquivo de automatiza��o do Windows.
ping localhost -n 2 >nul
cls

:oing2
chcp 1252 >nul
echo.
echo  Criando o seu arquivo de automatiza��o do Windows..
ping localhost -n 2 >nul
cls

:ping3
chcp 1252 >nul
echo.
echo  Criando o seu arquivo de automatiza��o do Windows...
ping localhost -n 2 >nul
goto create_oobe

::
:: Cria��o de arquivo "autounattend.xml"
::
:create_oobe
:: chcp 65001 >nul
( @echo ^<?xml version="1.0" encoding="utf-8"?^>
echo.
echo ^<!--   iMG-OtWIN - v.3.5 - Latest Version   --^>
echo ^<!-- wsinc_unattend.xml -^> autounattend.xml --^>
echo ^<!-- Criado por Wsinc Org :: @wssolinforbot --^>
echo.
echo ^<unattend xmlns="urn:schemas-microsoft-com:unattend" xmlns:wcm="http://schemas.microsoft.com/WMIConfig/2002/State"^>
echo     ^<settings pass="offlineServicing"^>^</settings^>
echo     ^<settings pass="windowsPE"^>
echo         ^<component name="Microsoft-Windows-International-Core-WinPE" processorArchitecture="%ARCH%" publicKeyToken="31bf3856ad364e35" language="neutral" versionScope="nonSxS"^>
echo             ^<UILanguage^>pt-BR^</UILanguage^>
echo         ^</component^>
echo         ^<component name="Microsoft-Windows-Setup" processorArchitecture="%ARCH%" publicKeyToken="31bf3856ad364e35" language="neutral" versionScope="nonSxS"^>
echo             ^<UserData^>
echo                 ^<AcceptEula^>true^</AcceptEula^>
echo             ^</UserData^>
echo             ^<UseConfigurationSet^>false^</UseConfigurationSet^>
echo             ^<RunSynchronous^>
echo                 ^<RunSynchronousCommand wcm:action="add"^>
echo                     ^<Order^>1^</Order^>
echo                     ^<Path^>reg.exe add "HKLM\SYSTEM\Setup\LabConfig" /v BypassTPMCheck /t REG_DWORD /d 1 /f^</Path^>
echo                 ^</RunSynchronousCommand^>
echo                 ^<RunSynchronousCommand wcm:action="add"^>
echo                     ^<Order^>2^</Order^>
echo                     ^<Path^>reg.exe add "HKLM\SYSTEM\Setup\LabConfig" /v BypassSecureBootCheck /t REG_DWORD /d 1 /f^</Path^>
echo                 ^</RunSynchronousCommand^>
echo                 ^<RunSynchronousCommand wcm:action="add"^>
echo                     ^<Order^>3^</Order^>
echo                     ^<Path^>reg.exe add "HKLM\SYSTEM\Setup\LabConfig" /v BypassRAMCheck /t REG_DWORD /d 1 /f^</Path^>
echo                 ^</RunSynchronousCommand^>
echo                 ^<RunSynchronousCommand wcm:action="add"^>
echo                     ^<Order^>4^</Order^>
echo                     ^<Path^>cmd.exe /c "&gt;&gt;"X:\defender.vbs" (echo:WScript.Echo ^"Scanning for newly created SYSTEM registry hive file to disable Windows Defender services...^^"&amp;echo:Set fso = CreateObject(^"Scripting.FileSystemObject^^"^))"^</Path^>
echo                 ^</RunSynchronousCommand^>
echo                 ^<RunSynchronousCommand wcm:action="add"^>
echo                     ^<Order^>5^</Order^>
echo                     ^<Path^>cmd.exe /c "&gt;&gt;"X:\defender.vbs" (echo:Set existing = CreateObject(^"Scripting.Dictionary^^"^)&amp;echo:Function Execute(command^)&amp;echo:WScript.Echo ^"Running command '^^" + command + ^"'^^"&amp;echo:Set shell = CreateObject(^"WScript.Shell^^"^))"^</Path^>
echo                 ^</RunSynchronousCommand^>
echo                 ^<RunSynchronousCommand wcm:action="add"^>
echo                     ^<Order^>6^</Order^>
echo                     ^<Path^>cmd.exe /c "&gt;&gt;"X:\defender.vbs" (echo:Set exec = shell.Exec(command^)&amp;echo:Do While exec.Status = 0&amp;echo:WScript.Sleep 100&amp;echo:Loop&amp;echo:WScript.Echo exec.StdOut.ReadAll&amp;echo:WScript.Echo exec.StdErr.ReadAll&amp;echo:Execute = exec.ExitCode)"^</Path^>
echo                 ^</RunSynchronousCommand^>
echo                 ^<RunSynchronousCommand wcm:action="add"^>
echo                     ^<Order^>7^</Order^>
echo                     ^<Path^>cmd.exe /c "&gt;&gt;"X:\defender.vbs" (echo:End Function&amp;echo:Function FindHiveFiles&amp;echo:Set FindHiveFiles = CreateObject(^"Scripting.Dictionary^^"^)&amp;echo:For Each drive In fso.Drives&amp;echo:If drive.IsReady And drive.DriveLetter ^&lt;^&gt; ^"X^^" Then)"^</Path^>
echo                 ^</RunSynchronousCommand^>
echo                 ^<RunSynchronousCommand wcm:action="add"^>
echo                     ^<Order^>8^</Order^>
echo                     ^<Path^>cmd.exe /c "&gt;&gt;"X:\defender.vbs" (echo:For Each folder In Array(^"$Windows.~BT\NewOS\Windows^^", ^"Windows^^"^)&amp;echo:file = fso.BuildPath(fso.BuildPath(drive.RootFolder, folder^), ^"System32\config\SYSTEM^^"^))"^</Path^>
echo                 ^</RunSynchronousCommand^>
echo                 ^<RunSynchronousCommand wcm:action="add"^>
echo                     ^<Order^>9^</Order^>
echo                     ^<Path^>cmd.exe /c "&gt;&gt;"X:\defender.vbs" (echo:If fso.FileExists(file^) And fso.FileExists(file + ^".LOG1^^"^) And fso.FileExists(file + ^".LOG2^^"^) Then&amp;echo:FindHiveFiles.Add file, Nothing&amp;echo:End If&amp;echo:Next&amp;echo:End If&amp;echo:Next&amp;echo:End Function)"^</Path^>
echo                 ^</RunSynchronousCommand^>
echo                 ^<RunSynchronousCommand wcm:action="add"^>
echo                     ^<Order^>10^</Order^>
echo                     ^<Path^>cmd.exe /c "&gt;&gt;"X:\defender.vbs" (echo:For Each file In FindHiveFiles&amp;echo:WScript.Echo ^"Will ignore file at '^^" + file + ^"' because it was already present when Windows Setup started.^^"&amp;echo:existing.Add file, Nothing&amp;echo:Next&amp;echo:Do)"^</Path^>
echo                 ^</RunSynchronousCommand^>
echo                 ^<RunSynchronousCommand wcm:action="add"^>
echo                     ^<Order^>11^</Order^>
echo                     ^<Path^>cmd.exe /c "&gt;&gt;"X:\defender.vbs" (echo:For Each file In FindHiveFiles&amp;echo:If Not existing.Exists(file^) Then&amp;echo:ret = 1&amp;echo:While ret ^&gt; 0&amp;echo:WScript.Sleep 500&amp;echo:ret = Execute(^"reg.exe LOAD HKLM\mount ^^" + file^)&amp;echo:Wend)"^</Path^>
echo                 ^</RunSynchronousCommand^>
echo                 ^<RunSynchronousCommand wcm:action="add"^>
echo                     ^<Order^>12^</Order^>
echo                     ^<Path^>cmd.exe /c "&gt;&gt;"X:\defender.vbs" (echo:For Each service In Array(^"Sense^^", ^"WdBoot^^", ^"WdFilter^^", ^"WdNisDrv^^", ^"WdNisSvc^^", ^"WinDefend^^"^))"^</Path^>
echo                 ^</RunSynchronousCommand^>
echo                 ^<RunSynchronousCommand wcm:action="add"^>
echo                     ^<Order^>13^</Order^>
echo                     ^<Path^>cmd.exe /c "&gt;&gt;"X:\defender.vbs" (echo:ret = Execute(^"reg.exe ADD HKLM\mount\ControlSet001\Services\^^" + service + ^" /v Start /t REG_DWORD /d 3 /f^^"^)&amp;echo:Next&amp;echo:ret = Execute(^"reg.exe UNLOAD HKLM\mount^^"^))"^</Path^>
echo                 ^</RunSynchronousCommand^>
echo                 ^<RunSynchronousCommand wcm:action="add"^>
echo                     ^<Order^>14^</Order^>
echo                     ^<Path^>cmd.exe /c "&gt;&gt;"X:\defender.vbs" (echo:WScript.Echo ^"Found and successfully modified SYSTEM registry hive file at '^^" + file + ^"'. This window will now close.^^"&amp;echo:WScript.Sleep 5000&amp;echo:Exit Do&amp;echo:End If&amp;echo:WScript.Sleep 1000&amp;echo:Next)"^</Path^>
echo                 ^</RunSynchronousCommand^>
echo                 ^<RunSynchronousCommand wcm:action="add"^>
echo                     ^<Order^>15^</Order^>
echo                     ^<Path^>cmd.exe /c "&gt;&gt;"X:\defender.vbs" (echo:Loop)"^</Path^>
echo                 ^</RunSynchronousCommand^>
echo                 ^<RunSynchronousCommand wcm:action="add"^>
echo                     ^<Order^>16^</Order^>
echo                     ^<Path^>cmd.exe /c "start /MIN cscript.exe //E:vbscript X:\defender.vbs"^</Path^>
echo                 ^</RunSynchronousCommand^>
echo             ^</RunSynchronous^>
echo         ^</component^>
echo     ^</settings^>
echo     ^<settings pass="specialize"^>
echo         ^<component name="Microsoft-Windows-Shell-Setup" processorArchitecture="%ARCH%" publicKeyToken="31bf3856ad364e35" language="neutral" versionScope="nonSxS"^>
echo             ^<ComputerName^>TEMPNAME^</ComputerName^>
echo         ^</component^>
echo         ^<component name="Microsoft-Windows-Deployment" processorArchitecture="%ARCH%" publicKeyToken="31bf3856ad364e35" language="neutral" versionScope="nonSxS"^>
echo             ^<RunSynchronous^>
echo                 ^<RunSynchronousCommand wcm:action="add"^>
echo                     ^<Order^>1^</Order^>
echo                     ^<Path^>powershell.exe -WindowStyle Hidden -NoProfile -Command "$xml = [xml]::new(); $xml.Load('C:\Windows\Panther\unattend.xml'); $sb = [scriptblock]::Create( $xml.unattend.Extensions.ExtractScript ); Invoke-Command -ScriptBlock $sb -ArgumentList $xml;"^</Path^>
echo                 ^</RunSynchronousCommand^>
echo                 ^<RunSynchronousCommand wcm:action="add"^>
echo                     ^<Order^>2^</Order^>
echo                     ^<Path^>powershell.exe -WindowStyle Hidden -NoProfile -Command "Get-Content -LiteralPath 'C:\Windows\Setup\Scripts\Specialize.ps1' -Raw | Invoke-Expression;"^</Path^>
echo                 ^</RunSynchronousCommand^>
echo                 ^<RunSynchronousCommand wcm:action="add"^>
echo                     ^<Order^>3^</Order^>
echo                     ^<Path^>reg.exe load "HKU\DefaultUser" "C:\Users\Default\NTUSER.DAT"^</Path^>
echo                 ^</RunSynchronousCommand^>
echo                 ^<RunSynchronousCommand wcm:action="add"^>
echo                     ^<Order^>4^</Order^>
echo                     ^<Path^>powershell.exe -WindowStyle Hidden -NoProfile -Command "Get-Content -LiteralPath 'C:\Windows\Setup\Scripts\DefaultUser.ps1' -Raw | Invoke-Expression;"^</Path^>
echo                 ^</RunSynchronousCommand^>
echo                 ^<RunSynchronousCommand wcm:action="add"^>
echo                     ^<Order^>5^</Order^>
echo                     ^<Path^>reg.exe unload "HKU\DefaultUser"^</Path^>
echo                 ^</RunSynchronousCommand^>
echo             ^</RunSynchronous^>
echo         ^</component^>
echo     ^</settings^>
echo     ^<settings pass="oobeSystem"^>
echo         ^<component name="Microsoft-Windows-International-Core" processorArchitecture="%ARCH%" publicKeyToken="31bf3856ad364e35" language="neutral" versionScope="nonSxS"^>
echo             ^<InputLocale^>0416:00000416^</InputLocale^>
echo             ^<SystemLocale^>pt-BR^</SystemLocale^>
echo             ^<UILanguage^>pt-BR^</UILanguage^>
echo             ^<UserLocale^>pt-BR^</UserLocale^>
echo         ^</component^>
echo         ^<component name="Microsoft-Windows-Shell-Setup" processorArchitecture="%ARCH%" publicKeyToken="31bf3856ad364e35" language="neutral" versionScope="nonSxS"^>
echo             ^<UserAccounts^>
echo                 ^<LocalAccounts^>
echo                     ^<LocalAccount wcm:action="add"^>
echo                         ^<Name^>%ADMINUSER%^</Name^>
echo                         ^<DisplayName^>%ADMINUSER%^</DisplayName^>
echo                         ^<Group^>Administrators^</Group^>
echo                         ^<Password^>
echo                             ^<Value^>%PASSWORD%^</Value^>
echo                             ^<PlainText^>true^</PlainText^>
echo                         ^</Password^>
echo                     ^</LocalAccount^>
echo                 ^</LocalAccounts^>
echo             ^</UserAccounts^>
echo             ^<AutoLogon^>
echo                 ^<Username^>%ADMINUSER%^</Username^>
echo                 ^<Enabled^>true^</Enabled^>
echo                 ^<LogonCount^>1^</LogonCount^>
echo                 ^<Password^>
echo                     ^<Value^>%PASSWORD%^</Value^>
echo                     ^<PlainText^>true^</PlainText^>
echo                 ^</Password^>
echo             ^</AutoLogon^>
echo             ^<OOBE^>
echo                 ^<ProtectYourPC^>3^</ProtectYourPC^>
echo                 ^<HideEULAPage^>true^</HideEULAPage^>
echo                 ^<HideWirelessSetupInOOBE^>true^</HideWirelessSetupInOOBE^>
echo                 ^<HideOnlineAccountScreens^>true^</HideOnlineAccountScreens^>
echo             ^</OOBE^>
echo             ^<FirstLogonCommands^>
echo                 ^<SynchronousCommand wcm:action="add"^>
echo                     ^<Order^>1^</Order^>
echo                     ^<CommandLine^>powershell.exe -WindowStyle Hidden -NoProfile -Command "Get-Content -LiteralPath 'C:\Windows\Setup\Scripts\FirstLogon.ps1' -Raw | Invoke-Expression;"^</CommandLine^>
echo                 ^</SynchronousCommand^>
echo             ^</FirstLogonCommands^>
echo         ^</component^>
echo     ^</settings^>
echo ^<Extensions xmlns="https://schneegans.de/windows/unattend-generator/"^>
echo         ^<ExtractScript^>
echo param^(
echo     [xml] $Document
echo ^);
echo.
echo foreach^( $file in $Document.unattend.Extensions.File ^) {
echo     $path = [System.Environment]::ExpandEnvironmentVariables^( $file.GetAttribute^( 'path' ^) ^);
echo     mkdir -Path^( $path ^| Split-Path -Parent ^) -ErrorAction 'SilentlyContinue';
echo     $encoding = switch^( [System.IO.Path]::GetExtension^( $path ^) ^) {
echo         { $_ -in '.ps1', '.xml' } { [System.Text.Encoding]::UTF8; }
echo         { $_ -in '.reg', '.vbs', '.js' } { [System.Text.UnicodeEncoding]::new^( $false, $true ^); }
echo         default { [System.Text.Encoding]::Default; }
echo     };
echo     $bytes = $encoding.GetPreamble^(^) + $encoding.GetBytes^( $file.InnerText.Trim^(^) ^);
echo     [System.IO.File]::WriteAllBytes^( $path, $bytes ^);
echo }
echo 		^</ExtractScript^>
echo         ^<File path="C:\Windows\Setup\Scripts\GetComputerName.ps1"^>
echo $timestamp = Get-Date -Format "yyyyMMddHHmmss"
echo return "PC-User{0}" -f ^($timestamp.Substring^($timestamp.Length - 4, 4^)^)
echo 		^</File^>
echo         ^<File path="C:\Windows\Setup\Scripts\SetComputerName.ps1"^>
echo $ErrorActionPreference = 'Stop';
echo Set-StrictMode -Version 'Latest';
echo ^&amp; {
echo 	$newName = ^( Get-Content -LiteralPath 'C:\Windows\Setup\Scripts\ComputerName.txt' -Raw ^).Trim^(^);
echo 	if^( [string]::IsNullOrWhitespace^( $newName ^) ^) {
echo 		throw "No computer name was provided.";
echo 	}
echo.
echo 	$keys = @^(
echo 		@{
echo 			LiteralPath = 'Registry::HKLM\SYSTEM\CurrentControlSet\Control\ComputerName\ComputerName';
echo 			Name = 'ComputerName';
echo 		};
echo 		@{
echo 			LiteralPath = 'Registry::HKLM\SYSTEM\CurrentControlSet\Services\Tcpip\Parameters';
echo 			Name = 'Hostname';
echo 		};
echo 		@{
echo 			LiteralPath = 'Registry::HKLM\SYSTEM\CurrentControlSet\Services\Tcpip\Parameters';
echo 			Name = 'NV Hostname';
echo 		};
echo 	^);
echo.
echo 	while^( $true ^) {
echo 		foreach^( $key in $keys ^) {
echo 			Set-ItemProperty @key -Type 'String' -Value $newName;
echo 		}
echo 		Start-Sleep -Milliseconds 50;
echo 	}
echo } *^&gt;^&amp;1 ^| Out-String ^&gt;^&gt; 'C:\Windows\Setup\Scripts\SetComputerName.log';
echo 		^</File^>
echo         ^<File path="C:\Windows\Setup\Scripts\RemovePackages.ps1"^>
echo $selectors = @^(
echo 	'Microsoft.BingSearch';
echo 	'Microsoft.Copilot';
echo 	'Microsoft.WindowsFeedbackHub';
echo 	'Microsoft.GetHelp';
echo 	'Microsoft.BingNews';
echo 	'Microsoft.MicrosoftOfficeHub';
echo 	'Microsoft.Office.OneNote';
echo 	'Microsoft.OutlookForWindows';
echo 	'MicrosoftCorporationII.QuickAssist';
echo 	'Microsoft.SkypeApp';
echo 	'MicrosoftTeams';
echo 	'MSTeams';
echo 	'Microsoft.Wallet';
echo 	'Microsoft.BingWeather';
echo 	'Microsoft.YourPhone';
echo ^);
echo $getCommand = {
echo   Get-AppxProvisionedPackage -Online;
echo };
echo $filterCommand = {
echo   $_.DisplayName -eq $selector;
echo };
echo $removeCommand = {
echo   [CmdletBinding^(^)]
echo   param^(
echo     [Parameter^( Mandatory, ValueFromPipeline ^)]
echo     $InputObject
echo   ^);
echo   process {
echo     $InputObject ^| Remove-AppxProvisionedPackage -AllUsers -Online -ErrorAction 'Continue';
echo   }
echo };
echo $type = 'Package';
echo $logfile = 'C:\Windows\Setup\Scripts\RemovePackages.log';
echo ^&amp; {
echo 	$installed = ^&amp; $getCommand;
echo 	foreach^( $selector in $selectors ^) {
echo 		$result = [ordered] @{
echo 			Selector = $selector;
echo 		};
echo 		$found = $installed ^| Where-Object -FilterScript $filterCommand;
echo 		if^( $found ^) {
echo 			$result.Output = $found ^| ^&amp; $removeCommand;
echo 			if^( $? ^) {
echo 				$result.Message = "$type removed.";
echo 			} else {
echo 				$result.Message = "$type not removed.";
echo 				$result.Error = $Error[0];
echo 			}
echo 		} else {
echo 			$result.Message = "$type not installed.";
echo 		}
echo 		$result ^| ConvertTo-Json -Depth 3 -Compress;
echo 	}
echo } *^&gt;^&amp;1 ^| Out-String ^&gt;^&gt; $logfile;
echo 		^</File^>
echo         ^<File path="C:\Windows\Setup\Scripts\RemoveCapabilities.ps1"^>
echo $selectors = @^(
echo 	'Browser.InternetExplorer';
echo 	'OneCoreUAP.OneSync';
echo 	'App.Support.QuickAssist';
echo 	'Hello.Face.18967';
echo 	'Hello.Face.Migration.18967';
echo 	'Hello.Face.20134';
echo 	'Media.WindowsMediaPlayer';
echo ^);
echo $getCommand = {
echo   Get-WindowsCapability -Online ^| Where-Object -Property 'State' -NotIn -Value @^(
echo     'NotPresent';
echo     'Removed';
echo   ^);
echo };
echo $filterCommand = {
echo   ^($_.Name -split '~'^)[0] -eq $selector;
echo };
echo $removeCommand = {
echo   [CmdletBinding^(^)]
echo   param^(
echo     [Parameter^( Mandatory, ValueFromPipeline ^)]
echo     $InputObject
echo   ^);
echo   process {
echo     $InputObject ^| Remove-WindowsCapability -Online -ErrorAction 'Continue';
echo   }
echo };
echo $type = 'Capability';
echo $logfile = 'C:\Windows\Setup\Scripts\RemoveCapabilities.log';
echo ^&amp; {
echo 	$installed = ^&amp; $getCommand;
echo 	foreach^( $selector in $selectors ^) {
echo 		$result = [ordered] @{
echo 			Selector = $selector;
echo 		};
echo 		$found = $installed ^| Where-Object -FilterScript $filterCommand;
echo 		if^( $found ^) {
echo 			$result.Output = $found ^| ^&amp; $removeCommand;
echo 			if^( $? ^) {
echo 				$result.Message = "$type removed.";
echo 			} else {
echo 				$result.Message = "$type not removed.";
echo 				$result.Error = $Error[0];
echo 			}
echo 		} else {
echo 			$result.Message = "$type not installed.";
echo 		}
echo 		$result ^| ConvertTo-Json -Depth 3 -Compress;
echo 	}
echo } *^&gt;^&amp;1 ^| Out-String ^&gt;^&gt; $logfile;
echo 		^</File^>
echo         ^<File path="C:\Windows\Setup\Scripts\PauseWindowsUpdate.ps1"^>
echo $formatter = {
echo 	$args[0].ToString^( "yyyy'-'MM'-'dd'T'HH':'mm':'ssK" ^);
echo };
echo $now = [datetime]::UtcNow;
echo $start = ^&amp; $formatter $now;
echo $end = ^&amp; $formatter $now.AddDays^( 7 ^);
echo.
echo $params = @{
echo 	LiteralPath = 'Registry::HKLM\SOFTWARE\Microsoft\WindowsUpdate\UX\Settings';
echo 	Type = 'String';
echo 	Force = $true;
echo };
echo.
echo Set-ItemProperty @params -Name 'PauseFeatureUpdatesStartTime' -Value $start;
echo Set-ItemProperty @params -Name 'PauseFeatureUpdatesEndTime' -Value $end;
echo Set-ItemProperty @params -Name 'PauseQualityUpdatesStartTime' -Value $start;
echo Set-ItemProperty @params -Name 'PauseQualityUpdatesEndTime' -Value $end;
echo Set-ItemProperty @params -Name 'PauseUpdatesStartTime' -Value $start;
echo Set-ItemProperty @params -Name 'PauseUpdatesExpiryTime' -Value $end;
echo 		^</File^>
echo         ^<File path="C:\Windows\Setup\Scripts\PauseWindowsUpdate.xml"^>
echo ^&lt;Task version="1.2" xmlns="http://schemas.microsoft.com/windows/2004/02/mit/task"^&gt;
echo 	^&lt;Triggers^&gt;
echo 		^&lt;BootTrigger^&gt;
echo 			^&lt;Repetition^&gt;
echo 				^&lt;Interval^&gt;P1D^&lt;/Interval^&gt;
echo 				^&lt;StopAtDurationEnd^&gt;false^&lt;/StopAtDurationEnd^&gt;
echo 			^&lt;/Repetition^&gt;
echo 			^&lt;Enabled^&gt;true^&lt;/Enabled^&gt;
echo 		^&lt;/BootTrigger^&gt;
echo 	^&lt;/Triggers^&gt;
echo 	^&lt;Principals^&gt;
echo 		^&lt;Principal id="Author"^&gt;
echo 			^&lt;UserId^&gt;S-1-5-19^&lt;/UserId^&gt;
echo 			^&lt;RunLevel^&gt;LeastPrivilege^&lt;/RunLevel^&gt;
echo 		^&lt;/Principal^&gt;
echo 	^&lt;/Principals^&gt;
echo 	^&lt;Settings^&gt;
echo 		^&lt;MultipleInstancesPolicy^&gt;IgnoreNew^&lt;/MultipleInstancesPolicy^&gt;
echo 		^&lt;DisallowStartIfOnBatteries^&gt;false^&lt;/DisallowStartIfOnBatteries^&gt;
echo 		^&lt;StopIfGoingOnBatteries^&gt;false^&lt;/StopIfGoingOnBatteries^&gt;
echo 		^&lt;AllowHardTerminate^&gt;true^&lt;/AllowHardTerminate^&gt;
echo 		^&lt;StartWhenAvailable^&gt;false^&lt;/StartWhenAvailable^&gt;
echo 		^&lt;RunOnlyIfNetworkAvailable^&gt;false^&lt;/RunOnlyIfNetworkAvailable^&gt;
echo 		^&lt;IdleSettings^&gt;
echo 			^&lt;StopOnIdleEnd^&gt;true^&lt;/StopOnIdleEnd^&gt;
echo 			^&lt;RestartOnIdle^&gt;false^&lt;/RestartOnIdle^&gt;
echo 		^&lt;/IdleSettings^&gt;
echo 		^&lt;AllowStartOnDemand^&gt;true^&lt;/AllowStartOnDemand^&gt;
echo 		^&lt;Enabled^&gt;true^&lt;/Enabled^&gt;
echo 		^&lt;Hidden^&gt;false^&lt;/Hidden^&gt;
echo 		^&lt;RunOnlyIfIdle^&gt;false^&lt;/RunOnlyIfIdle^&gt;
echo 		^&lt;WakeToRun^&gt;false^&lt;/WakeToRun^&gt;
echo 		^&lt;ExecutionTimeLimit^&gt;PT72H^&lt;/ExecutionTimeLimit^&gt;
echo 		^&lt;Priority^&gt;7^&lt;/Priority^&gt;
echo 	^&lt;/Settings^&gt;
echo 	^&lt;Actions Context="Author"^&gt;
echo 		^&lt;Exec^&gt;
echo 			^&lt;Command^&gt;C:\Windows\System32\WindowsPowerShell\v1.0\powershell.exe^&lt;/Command^&gt;
echo 			^&lt;Arguments^&gt;-Command "Get-Content -LiteralPath 'C:\Windows\Setup\Scripts\PauseWindowsUpdate.ps1' -Raw ^| Invoke-Expression;"^&lt;/Arguments^&gt;
echo 		^&lt;/Exec^&gt;
echo 	^&lt;/Actions^&gt;
echo ^&lt;/Task^&gt;
echo 		^</File^>
echo         ^<File path="C:\Windows\Setup\Scripts\SetStartPins.ps1"^>
echo $json = '{"pinnedList":[]}';
echo if^( [System.Environment]::OSVersion.Version.Build -lt 20000 ^) {
echo 	return;
echo }
echo $key = 'Registry::HKLM\SOFTWARE\Microsoft\PolicyManager\current\device\Start';
echo New-Item -Path $key -ItemType 'Directory' -ErrorAction 'SilentlyContinue';
echo Set-ItemProperty -LiteralPath $key -Name 'ConfigureStartPins' -Value $json -Type 'String';
echo 		^</File^>
echo         ^<File path="C:\Windows\Setup\Scripts\Specialize.ps1"^>
echo $scripts = @^(
echo 	{
echo 		Get-Content -LiteralPath 'C:\Windows\Setup\Scripts\GetComputerName.ps1' -Raw ^| Invoke-Expression ^&gt; 'C:\Windows\Setup\Scripts\ComputerName.txt';
echo 		Start-Process -FilePath ^( Get-Process -Id $PID ^).Path -ArgumentList '-NoProfile', '-Command', 'Get-Content -LiteralPath "C:\Windows\Setup\Scripts\SetComputerName.ps1" -Raw ^| Invoke-Expression;' -WindowStyle 'Hidden';
echo 		Start-Sleep -Seconds 10;
echo 	};
echo 	{
echo 		reg.exe add "HKLM\SYSTEM\Setup\MoSetup" /v AllowUpgradesWithUnsupportedTPMOrCPU /t REG_DWORD /d 1 /f;
echo 	};
echo 	{
echo 		Remove-Item -LiteralPath 'C:\Users\Default\AppData\Roaming\Microsoft\Windows\Start Menu\Programs\OneDrive.lnk', 'C:\Windows\System32\OneDriveSetup.exe', 'C:\Windows\SysWOW64\OneDriveSetup.exe' -ErrorAction 'Continue';
echo 	};
echo 	{
echo 		Remove-Item -LiteralPath 'Registry::HKLM\Software\Microsoft\WindowsUpdate\Orchestrator\UScheduler_Oobe\OutlookUpdate' -Force -ErrorAction 'SilentlyContinue';
echo 	};
echo 	{
echo 		reg.exe add "HKLM\SOFTWARE\Microsoft\Windows\CurrentVersion\Communications" /v ConfigureChatAutoInstall /t REG_DWORD /d 0 /f;
echo 	};
echo 	{
echo 		Get-Content -LiteralPath 'C:\Windows\Setup\Scripts\RemovePackages.ps1' -Raw ^| Invoke-Expression;
echo 	};
echo 	{
echo 		Get-Content -LiteralPath 'C:\Windows\Setup\Scripts\RemoveCapabilities.ps1' -Raw ^| Invoke-Expression;
echo 	};
echo 	{
echo 		net.exe accounts /maxpwage:UNLIMITED;
echo 	};
echo 	{
echo 		Register-ScheduledTask -TaskName 'PauseWindowsUpdate' -Xml $^( Get-Content -LiteralPath 'C:\Windows\Setup\Scripts\PauseWindowsUpdate.xml' -Raw ^);
echo 	};
echo 	{
echo 		reg.exe add "HKLM\SOFTWARE\Policies\Microsoft\Windows Defender Security Center\Notifications" /v DisableNotifications /t REG_DWORD /d 1 /f;
echo 	};
echo 	{
echo 		Set-ExecutionPolicy -Scope 'LocalMachine' -ExecutionPolicy 'RemoteSigned' -Force;
echo 	};
echo 	{
echo 		fsutil.exe behavior set disableLastAccess 1;
echo 	};
echo 	{
echo 		reg.exe add "HKLM\SOFTWARE\Policies\Microsoft\Dsh" /v AllowNewsAndInterests /t REG_DWORD /d 0 /f;
echo 	};
echo 	{
echo 		reg.exe add "HKLM\Software\Policies\Microsoft\Windows\CloudContent" /v "DisableWindowsConsumerFeatures" /t REG_DWORD /d 1 /f;
echo 	};
echo 	{
echo 		reg.exe add "HKLM\SYSTEM\CurrentControlSet\Control\BitLocker" /v "PreventDeviceEncryption" /t REG_DWORD /d 1 /f;
echo 	};
echo 	{
echo 		reg.exe add "HKLM\Software\Policies\Microsoft\Edge" /v HideFirstRunExperience /t REG_DWORD /d 1 /f;
echo 	};
echo 	{
echo 		reg.exe add "HKLM\Software\Policies\Microsoft\Edge\Recommended" /v BackgroundModeEnabled /t REG_DWORD /d 0 /f;
echo 		reg.exe add "HKLM\Software\Policies\Microsoft\Edge\Recommended" /v StartupBoostEnabled /t REG_DWORD /d 0 /f;
echo 	};
echo 	{
echo 		Get-Content -LiteralPath 'C:\Windows\Setup\Scripts\SetStartPins.ps1' -Raw ^| Invoke-Expression;
echo 	};
echo ^);
echo.
echo ^&amp; {
echo   [float] $complete = 0;
echo   [float] $increment = 100 / $scripts.Count;
echo   foreach^( $script in $scripts ^) {
echo     Write-Progress -Activity 'Running scripts to customize your Windows installation. Do not close this window.' -PercentComplete $complete;
echo     '*** Will now execute command ^&#xAB;{0}^&#xBB;.' -f $^(
echo       $str = $script.ToString^(^).Trim^(^) -replace '\s+', ' ';
echo       $max = 100;
echo       if^( $str.Length -le $max ^) {
echo         $str;
echo       } else {
echo         $str.Substring^( 0, $max - 1 ^) + '^&#x2026;';
echo       }
echo     ^);
echo     $start = [datetime]::Now;
echo     ^&amp; $script;
echo     '*** Finished executing command after {0:0} ms.' -f [datetime]::Now.Subtract^( $start ^).TotalMilliseconds;
echo     "`r`n" * 3;
echo     $complete += $increment;
echo   }
echo } *^&gt;^&amp;1 ^| Out-String ^&gt;^&gt; "C:\Windows\Setup\Scripts\Specialize.log";
echo 		^</File^>
echo         ^<File path="C:\Windows\Setup\Scripts\UserOnce.ps1"^>
echo $scripts = @^(
echo 	{
echo 		Get-AppxPackage -Name 'Microsoft.Windows.Ai.Copilot.Provider' ^| Remove-AppxPackage;
echo 	};
echo 	{
echo 		New-Item -Path 'Registry::HKEY_CURRENT_USER\Software\Microsoft\Windows\CurrentVersion\Explorer\HideDesktopIcons\ClassicStartMenu' -Force;
echo 		Set-ItemProperty -Path 'Registry::HKEY_CURRENT_USER\Software\Microsoft\Windows\CurrentVersion\Explorer\HideDesktopIcons\ClassicStartMenu' -Name '{5399e694-6ce5-4d6c-8fce-1d8870fdcba0}' -Value 0 -Type 'DWord';
echo 		Set-ItemProperty -Path 'Registry::HKEY_CURRENT_USER\Software\Microsoft\Windows\CurrentVersion\Explorer\HideDesktopIcons\ClassicStartMenu' -Name '{b4bfcc3a-db2c-424c-b029-7fe99a87c641}' -Value 1 -Type 'DWord';
echo 		Set-ItemProperty -Path 'Registry::HKEY_CURRENT_USER\Software\Microsoft\Windows\CurrentVersion\Explorer\HideDesktopIcons\ClassicStartMenu' -Name '{a8cdff1c-4878-43be-b5fd-f8091c1c60d0}' -Value 1 -Type 'DWord';
echo 		Set-ItemProperty -Path 'Registry::HKEY_CURRENT_USER\Software\Microsoft\Windows\CurrentVersion\Explorer\HideDesktopIcons\ClassicStartMenu' -Name '{374de290-123f-4565-9164-39c4925e467b}' -Value 1 -Type 'DWord';
echo 		Set-ItemProperty -Path 'Registry::HKEY_CURRENT_USER\Software\Microsoft\Windows\CurrentVersion\Explorer\HideDesktopIcons\ClassicStartMenu' -Name '{e88865ea-0e1c-4e20-9aa6-edcd0212c87c}' -Value 1 -Type 'DWord';
echo 		Set-ItemProperty -Path 'Registry::HKEY_CURRENT_USER\Software\Microsoft\Windows\CurrentVersion\Explorer\HideDesktopIcons\ClassicStartMenu' -Name '{f874310e-b6b7-47dc-bc84-b9e6b38f5903}' -Value 0 -Type 'DWord';
echo 		Set-ItemProperty -Path 'Registry::HKEY_CURRENT_USER\Software\Microsoft\Windows\CurrentVersion\Explorer\HideDesktopIcons\ClassicStartMenu' -Name '{1cf1260c-4dd0-4ebb-811f-33c572699fde}' -Value 1 -Type 'DWord';
echo 		Set-ItemProperty -Path 'Registry::HKEY_CURRENT_USER\Software\Microsoft\Windows\CurrentVersion\Explorer\HideDesktopIcons\ClassicStartMenu' -Name '{f02c1a0d-be21-4350-88b0-7367fc96ef3c}' -Value 0 -Type 'DWord';
echo 		Set-ItemProperty -Path 'Registry::HKEY_CURRENT_USER\Software\Microsoft\Windows\CurrentVersion\Explorer\HideDesktopIcons\ClassicStartMenu' -Name '{3add1653-eb32-4cb0-bbd7-dfa0abb5acca}' -Value 1 -Type 'DWord';
echo 		Set-ItemProperty -Path 'Registry::HKEY_CURRENT_USER\Software\Microsoft\Windows\CurrentVersion\Explorer\HideDesktopIcons\ClassicStartMenu' -Name '{645ff040-5081-101b-9f08-00aa002f954e}' -Value 0 -Type 'DWord';
echo 		Set-ItemProperty -Path 'Registry::HKEY_CURRENT_USER\Software\Microsoft\Windows\CurrentVersion\Explorer\HideDesktopIcons\ClassicStartMenu' -Name '{20d04fe0-3aea-1069-a2d8-08002b30309d}' -Value 0 -Type 'DWord';
echo 		Set-ItemProperty -Path 'Registry::HKEY_CURRENT_USER\Software\Microsoft\Windows\CurrentVersion\Explorer\HideDesktopIcons\ClassicStartMenu' -Name '{59031a47-3f72-44a7-89c5-5595fe6b30ee}' -Value 0 -Type 'DWord';
echo 		Set-ItemProperty -Path 'Registry::HKEY_CURRENT_USER\Software\Microsoft\Windows\CurrentVersion\Explorer\HideDesktopIcons\ClassicStartMenu' -Name '{a0953c92-50dc-43bf-be83-3742fed03c9c}' -Value 1 -Type 'DWord';
echo 		New-Item -Path 'Registry::HKEY_CURRENT_USER\Software\Microsoft\Windows\CurrentVersion\Explorer\HideDesktopIcons\NewStartPanel' -Force;
echo 		Set-ItemProperty -Path 'Registry::HKEY_CURRENT_USER\Software\Microsoft\Windows\CurrentVersion\Explorer\HideDesktopIcons\NewStartPanel' -Name '{5399e694-6ce5-4d6c-8fce-1d8870fdcba0}' -Value 0 -Type 'DWord';
echo 		Set-ItemProperty -Path 'Registry::HKEY_CURRENT_USER\Software\Microsoft\Windows\CurrentVersion\Explorer\HideDesktopIcons\NewStartPanel' -Name '{b4bfcc3a-db2c-424c-b029-7fe99a87c641}' -Value 1 -Type 'DWord';
echo 		Set-ItemProperty -Path 'Registry::HKEY_CURRENT_USER\Software\Microsoft\Windows\CurrentVersion\Explorer\HideDesktopIcons\NewStartPanel' -Name '{a8cdff1c-4878-43be-b5fd-f8091c1c60d0}' -Value 1 -Type 'DWord';
echo 		Set-ItemProperty -Path 'Registry::HKEY_CURRENT_USER\Software\Microsoft\Windows\CurrentVersion\Explorer\HideDesktopIcons\NewStartPanel' -Name '{374de290-123f-4565-9164-39c4925e467b}' -Value 1 -Type 'DWord';
echo 		Set-ItemProperty -Path 'Registry::HKEY_CURRENT_USER\Software\Microsoft\Windows\CurrentVersion\Explorer\HideDesktopIcons\NewStartPanel' -Name '{e88865ea-0e1c-4e20-9aa6-edcd0212c87c}' -Value 1 -Type 'DWord';
echo 		Set-ItemProperty -Path 'Registry::HKEY_CURRENT_USER\Software\Microsoft\Windows\CurrentVersion\Explorer\HideDesktopIcons\NewStartPanel' -Name '{f874310e-b6b7-47dc-bc84-b9e6b38f5903}' -Value 0 -Type 'DWord';
echo 		Set-ItemProperty -Path 'Registry::HKEY_CURRENT_USER\Software\Microsoft\Windows\CurrentVersion\Explorer\HideDesktopIcons\NewStartPanel' -Name '{1cf1260c-4dd0-4ebb-811f-33c572699fde}' -Value 1 -Type 'DWord';
echo 		Set-ItemProperty -Path 'Registry::HKEY_CURRENT_USER\Software\Microsoft\Windows\CurrentVersion\Explorer\HideDesktopIcons\NewStartPanel' -Name '{f02c1a0d-be21-4350-88b0-7367fc96ef3c}' -Value 0 -Type 'DWord';
echo 		Set-ItemProperty -Path 'Registry::HKEY_CURRENT_USER\Software\Microsoft\Windows\CurrentVersion\Explorer\HideDesktopIcons\NewStartPanel' -Name '{3add1653-eb32-4cb0-bbd7-dfa0abb5acca}' -Value 1 -Type 'DWord';
echo 		Set-ItemProperty -Path 'Registry::HKEY_CURRENT_USER\Software\Microsoft\Windows\CurrentVersion\Explorer\HideDesktopIcons\NewStartPanel' -Name '{645ff040-5081-101b-9f08-00aa002f954e}' -Value 0 -Type 'DWord';
echo 		Set-ItemProperty -Path 'Registry::HKEY_CURRENT_USER\Software\Microsoft\Windows\CurrentVersion\Explorer\HideDesktopIcons\NewStartPanel' -Name '{20d04fe0-3aea-1069-a2d8-08002b30309d}' -Value 0 -Type 'DWord';
echo 		Set-ItemProperty -Path 'Registry::HKEY_CURRENT_USER\Software\Microsoft\Windows\CurrentVersion\Explorer\HideDesktopIcons\NewStartPanel' -Name '{59031a47-3f72-44a7-89c5-5595fe6b30ee}' -Value 0 -Type 'DWord';
echo 		Set-ItemProperty -Path 'Registry::HKEY_CURRENT_USER\Software\Microsoft\Windows\CurrentVersion\Explorer\HideDesktopIcons\NewStartPanel' -Name '{a0953c92-50dc-43bf-be83-3742fed03c9c}' -Value 1 -Type 'DWord';
echo 		Get-Process -Name 'explorer' -ErrorAction 'SilentlyContinue' ^| Where-Object -FilterScript {
echo 			$_.SessionId -eq ^( Get-Process -Id $PID ^).SessionId;
echo 		} ^| Stop-Process -Force;
echo 	};
echo ^);
echo.
echo ^&amp; {
echo   [float] $complete = 0;
echo   [float] $increment = 100 / $scripts.Count;
echo   foreach^( $script in $scripts ^) {
echo     Write-Progress -Activity 'Running scripts to configure this user account. Do not close this window.' -PercentComplete $complete;
echo     '*** Will now execute command ^&#xAB;{0}^&#xBB;.' -f $^(
echo       $str = $script.ToString^(^).Trim^(^) -replace '\s+', ' ';
echo       $max = 100;
echo       if^( $str.Length -le $max ^) {
echo         $str;
echo       } else {
echo         $str.Substring^( 0, $max - 1 ^) + '^&#x2026;';
echo       }
echo     ^);
echo     $start = [datetime]::Now;
echo     ^&amp; $script;
echo     '*** Finished executing command after {0:0} ms.' -f [datetime]::Now.Subtract^( $start ^).TotalMilliseconds;
echo     "`r`n" * 3;
echo     $complete += $increment;
echo   }
echo } *^&gt;^&amp;1 ^| Out-String ^&gt;^&gt; "$env:TEMP\UserOnce.log";
echo 		^</File^>
echo         ^<File path="C:\Windows\Setup\Scripts\DefaultUser.ps1"^>
echo $scripts = @^(
echo 	{
echo 		reg.exe add "HKU\DefaultUser\Software\Policies\Microsoft\Windows\WindowsCopilot" /v TurnOffWindowsCopilot /t REG_DWORD /d 1 /f;
echo 	};
echo 	{
echo 		reg.exe add "HKU\DefaultUser\Software\Microsoft\Internet Explorer\LowRegistry\Audio\PolicyConfig\PropertyStore" /f;
echo 	};
echo 	{
echo 		Remove-ItemProperty -LiteralPath 'Registry::HKU\DefaultUser\Software\Microsoft\Windows\CurrentVersion\Run' -Name 'OneDriveSetup' -Force -ErrorAction 'Continue';
echo 	};
echo 	{
echo 		$names = @^(
echo 		  'ContentDeliveryAllowed';
echo 		  'FeatureManagementEnabled';
echo 		  'OEMPreInstalledAppsEnabled';
echo 		  'PreInstalledAppsEnabled';
echo 		  'PreInstalledAppsEverEnabled';
echo 		  'SilentInstalledAppsEnabled';
echo 		  'SoftLandingEnabled';
echo 		  'SubscribedContentEnabled';
echo 		  'SubscribedContent-310093Enabled';
echo 		  'SubscribedContent-338387Enabled';
echo 		  'SubscribedContent-338388Enabled';
echo 		  'SubscribedContent-338389Enabled';
echo 		  'SubscribedContent-338393Enabled';
echo 		  'SubscribedContent-353694Enabled';
echo 		  'SubscribedContent-353696Enabled';
echo 		  'SubscribedContent-353698Enabled';
echo 		  'SystemPaneSuggestionsEnabled';
echo 		^);
echo.
echo 		foreach^( $name in $names ^) {
echo 		  reg.exe add "HKU\DefaultUser\Software\Microsoft\Windows\CurrentVersion\ContentDeliveryManager" /v $name /t REG_DWORD /d 0 /f;
echo 		}
echo 	};
echo 	{
echo 		reg.exe add "HKU\DefaultUser\Software\Policies\Microsoft\Windows\Explorer" /v DisableSearchBoxSuggestions /t REG_DWORD /d 1 /f;
echo 	};
echo 	{
echo 		reg.exe add "HKU\DefaultUser\Software\Microsoft\Windows\CurrentVersion\RunOnce" /v "UnattendedSetup" /t REG_SZ /d "powershell.exe -WindowStyle Hidden -NoProfile -Command \""Get-Content -LiteralPath 'C:\Windows\Setup\Scripts\UserOnce.ps1' -Raw ^| Invoke-Expression;\""" /f;
echo 	};
echo ^);
echo.
echo ^&amp; {
echo   [float] $complete = 0;
echo   [float] $increment = 100 / $scripts.Count;
echo   foreach^( $script in $scripts ^) {
echo     Write-Progress -Activity 'Running scripts to modify the default user^&#x2019;^&#x2019;s registry hive. Do not close this window.' -PercentComplete $complete;
echo     '*** Will now execute command ^&#xAB;{0}^&#xBB;.' -f $^(
echo       $str = $script.ToString^(^).Trim^(^) -replace '\s+', ' ';
echo       $max = 100;
echo       if^( $str.Length -le $max ^) {
echo         $str;
echo       } else {
echo         $str.Substring^( 0, $max - 1 ^) + '^&#x2026;';
echo       }
echo     ^);
echo     $start = [datetime]::Now;
echo     ^&amp; $script;
echo     '*** Finished executing command after {0:0} ms.' -f [datetime]::Now.Subtract^( $start ^).TotalMilliseconds;
echo     "`r`n" * 3;
echo     $complete += $increment;
echo   }
echo } *^&gt;^&amp;1 ^| Out-String ^&gt;^&gt; "C:\Windows\Setup\Scripts\DefaultUser.log";
echo 		^</File^>
echo         ^<File path="C:\Windows\Setup\Scripts\FirstLogon.ps1"^>
echo $scripts = @^(
echo 	{
echo 		Set-ItemProperty -LiteralPath 'Registry::HKLM\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Winlogon' -Name 'AutoLogonCount' -Type 'DWord' -Force -Value 0;
echo 	};
echo 	{
echo 		cmd.exe /c "rmdir C:\Windows.old";
echo 	};
echo 	{
echo 		Remove-Item -LiteralPath @^(
echo 		  'C:\Windows\Panther\unattend.xml';
echo 		  'C:\Windows\Panther\unattend-original.xml';
echo 		  'C:\Windows\Setup\Scripts\Wifi.xml';
echo 		^) -Force -ErrorAction 'SilentlyContinue' -Verbose;
echo 	};
echo ^);
echo.
echo ^&amp; {
echo   [float] $complete = 0;
echo   [float] $increment = 100 / $scripts.Count;
echo   foreach^( $script in $scripts ^) {
echo     Write-Progress -Activity 'Running scripts to finalize your Windows installation. Do not close this window.' -PercentComplete $complete;
echo     '*** Will now execute command ^&#xAB;{0}^&#xBB;.' -f $^(
echo       $str = $script.ToString^(^).Trim^(^) -replace '\s+', ' ';
echo       $max = 100;
echo       if^( $str.Length -le $max ^) {
echo         $str;
echo       } else {
echo         $str.Substring^( 0, $max - 1 ^) + '^&#x2026;';
echo       }
echo     ^);
echo     $start = [datetime]::Now;
echo     ^&amp; $script;
echo     '*** Finished executing command after {0:0} ms.' -f [datetime]::Now.Subtract^( $start ^).TotalMilliseconds;
echo     "`r`n" * 3;
echo     $complete += $increment;
echo   }
echo } *^&gt;^&amp;1 ^| Out-String ^&gt;^&gt; "C:\Windows\Setup\Scripts\FirstLogon.log";
echo 		^</File^>
echo     ^</Extensions^>
echo     ^<cpi:offlineImage cpi:source="" xmlns:cpi="urn:schemas-microsoft-com:cpi" /^>
echo ^</unattend^> ) > "%files%\media\autounattend.xml" && goto minify

::
:: Minifica o arquivo "autounattend.xml" gerado
::
:minify
powershell -Command "$c=Get-Content '%files%\media\autounattend.xml' -Raw;$c=$c-replace '>\s+<','><';$c=$c-replace '\s+',' ';$c|Set-Content '%files%\media\autounattend.xml' -NoNewline"
timeout /t 1 >nul

::
:: Gera arquivo "LEIA-ME.txt"
::
:create_leia-me
(@echo - Desmonte a sua ISO dando um duplo clique;
echo.
echo - Copie e cole todo o conte�do da ISO para a pasta "media".;
echo.
echo - Ap�s isso, use o gerador de .ISO para gerar a sua ISO j� com a automa��o.
echo.
echo - Seu arquivo de automa��o j� est� l�.
echo.
echo :: ====== ::
echo :: [INFO] ::
echo :: ====== ::
echo. 
echo :: Arquivo "autounattend.xml" criado e validado por WsSolInfor / WsincOrg) > "%files%\OOBE-Creator-Wsinc\LEIA-ME.txt"
timeout /t 1 >nul

::
:: Informa��o de cria��o de arquivo
::
:info_success
cls
echo.
powershell -Command "Write-Host ' ' -ForegroundColor Red -NoNewline; " ^
	"Write-Host ' Arquivo criado com sucesso! ' -ForegroundColor White -BackgroundColor DarkGreen -NoNewline; " ^
	"Write-Host ''; ''; " ^
	"Write-Host ' Local: ' -ForegroundColor Gray -NoNewline; " ^
	"Write-Host '%files%\media\' -ForegroundColor DarkBlue; "
echo.
echo  Pressione qualquer tecla para sair. . .
pause >nul

goto :eof